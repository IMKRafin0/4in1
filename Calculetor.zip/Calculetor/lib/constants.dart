import 'package:flutter/material.dart';

final Color kBackground = Color.fromARGB(255, 230, 228, 228);
final Color kLightGray = Color.fromARGB(255, 0, 0, 0);
final Color kDarkGray = Color.fromARGB(255, 243, 237, 237);
final Color kRed = Color(0xFFB60000);
final Color kAmber = Color(0xFFf7921e);
final Color kBlack = Color.fromARGB(250, 255, 255, 255);
final Color kWhite = Color.fromARGB(211, 17, 17, 17);