package com.example.calculetor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
